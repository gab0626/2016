#pragma once
#include "lib/framework.hpp"
#include "Singleton.h"
#include "Game.h"
#include "Title.h"
#include "Rules.h"
#include "Result.h"

enum SceneNumber
{
	TITLE,
	RULES,
	GAME,
	RESULT
};

class SceneManeger
{
private:
	Title title;
	Game game;
	Rules rules;
	Result result;

public:
	SceneManeger();
	
	void Draw();
	void Setup();
	void Update();
	void SoundSet();
	void SoundStop();
	void Shift();

	int Scene;
};