#pragma once
#include "lib/framework.hpp"

class Result
{
private:
	Font ResultFont = Font("res/MyComSquare-Medium.otf");
	Media ResultSound = Media("res/Love_Smile.wav");

public:
	Result();

	void Draw();
	void Setup();
	void Update();
	void SoundSet();
	void SoundStop();
	void Reset();

	float ColorR  = 0.0f;
	float ColorG  = 0.0f;
	float ColorB  = 0.0f;
	float Alfa    = 0.0f;
	float Alfa2   = 0.0f;
	float Alfa3   = 0.0f;

	bool AlfaFlag  = false;
	bool AlfaFlag2 = false;
	bool AlfaFlag3 = false;
};