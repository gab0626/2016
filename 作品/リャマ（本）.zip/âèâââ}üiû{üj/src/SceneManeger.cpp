#include "SceneManeger.h"

SceneManeger::SceneManeger()
{
	Scene = 0;
}

void SceneManeger::Setup()
{
	switch (Scene)
	{
	default:
		break;

	case TITLE:
		title.Setup();
		break;

	case RULES:
		rules.Setup();
		break;

	case GAME:
		game.Setup();
		break;

	case RESULT:
		result.Setup();
		break;

	}
}

void SceneManeger::Update()
{
	switch (Scene)
	{
	default:
		break;

	case TITLE:
		title.Update();
		break;

	case RULES:
		rules.Update();
		break;

	case GAME:
		game.Update();
		break;

	case RESULT:
		result.Update();
		break;

	}
}

void SceneManeger::SoundSet()
{
	switch (Scene)
	{
	default:
		break;

	case TITLE:
		title.SoundSet();
		break;

	case RULES:
		rules.SoundSet();
		break;

	case GAME:
		game.SoundSet();
		break;

	case RESULT:
		result.SoundSet();
		break;
	}
}

void SceneManeger::SoundStop()
{
	switch (Scene)
	{
	default:
		break;

	case TITLE:
		result.SoundStop();
		break;

	case RULES:
		title.SoundStop();
		break;

	case GAME:
		rules.SoundStop();
		break;

	case RESULT:
		game.SoundStop();
		break;
	}
}

void SceneManeger::Draw()
{
	switch (Scene)
	{
	default:
		break;

	case TITLE:
		title.Draw();
		break;

	case RULES:
		rules.Draw();
		break;

	case GAME:
		game.Draw();
		game.StartEnemyAnimation();
		game.HitAction();
		game.Goal();
		break;

	case RESULT:
		result.Draw();
		break;
	}
}

void SceneManeger::Shift()
{
	switch (Scene)
	{
	default:
		break;

	case TITLE:
		if (env.isPushButton(Mouse::LEFT))
		{
			Scene = (Scene + 1) % 4;
			title.TitleReset();
			Setup();
			SoundSet();
			
		}

		break;

	case RULES:
		if (rules.CanMoveFlag == false)
		/*if (env.isPushButton(Mouse::LEFT))*/
		{
			Scene = (Scene + 1) % 4;
			rules.RulesReset();
			Setup();
			SoundSet();
		}

		break;

	case GAME:
		if (game.CanMoveFlag == false)
		/*if (env.isPushButton(Mouse::LEFT))*/
		{
			Scene = (Scene + 1) % 4;
			game.LamaresetPos();
			game.EnemyResetPos();
			Setup();
			SoundSet();
		}

		break;

	case RESULT:
		if (env.isPushButton(Mouse::LEFT))
		{
			Scene = (Scene + 1) % 4;
			result.Reset();
			Setup();
			SoundSet();
		}
		
		break;
	}
}

