﻿#include "lib/framework.hpp"
#include "Singleton.h"
#include "SceneManeger.h"

int main() {
	
  env;
  SceneManeger scenemaneger;
  scenemaneger.Setup();
  scenemaneger.SoundSet();
  

  while (env.isOpen()) {

    env.begin();

	scenemaneger.Update();
	scenemaneger.SoundStop();
	scenemaneger.Shift();
	scenemaneger.Draw();
	

    env.end();
  }
}
