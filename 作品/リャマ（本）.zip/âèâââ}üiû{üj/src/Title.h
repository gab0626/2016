#pragma once
#include "lib/framework.hpp"
#include "Singleton.h"

class Title
{
private:

	Media TitleBackSound = Media("res/lama to girl.wav");
	Media CrickSound = Media("res/yubi.wav");
	Texture TitleBack;
	Texture TitleRogo;
	Font TitleFont = ("res/MyComSquare-Medium.otf");

	float TransparencyCount = 0.0f;
	float Transparency = 1.0f;


public:
	Title();

	void Draw();
	void Setup();
	void Update();
	void SoundSet();
	void TitleReset();
	void SoundStop();

	float Startdraw_x = -700.0f;
	float Startdraw_y = 300.0f;
	float Enddraw_x = 900.0f;
	float Enddraw_y = 128.0f;
	float Easing_x;
	float Easing_y;
	float t = 0;
};