#include "Rules.h"
#include <stdio.h>
#include <iostream>

Rules::Rules()
{
	Rules_BackScream = Texture("res/title.png");
	Rules_Lama = Texture("res/Lama.png");
	
}

void Rules::Setup()
{
	RulesFont.size(50);

	LamaDrawPos    = Vec2f(-630.0f, -400.0f);
	LamaSize       = Vec2f(64.0f, 120.0f);
	TextureDrawCos = Vec2f(64.0f, 128.0f);
	AnimationCount = 0.0f;
	RightMove      = false;
	LeftMove       = false;
	UpMove         = false;
	DownMove       = false;
}

void Rules::Update()
{
	BackGroundTransparency += 0.01;

	if (BackGroundTransparency >= 0.5f)
	{
		BackGroundTransparency = 0.5f;
	}

	if (LamaDrawPos.x() > 600 && LamaDrawPos.y() < -200)
	{
		Sound.play();
		CanMoveFlag = false;
	}
}

void Rules::SoundSet()
{
	RulesSound.play();
	RulesSound.gain(0.5);
}

void Rules::SoundStop()
{
	RulesSound.stop();
}

void Rules::Draw()
{
	drawTextureBox(DrawFirstPoint.x(), DrawFirstPoint.y(), DrawCost.x(), DrawCost.y(), TextureFirstPoint, TextureFirstPoint, TextureEndPoint.x(), TextureEndPoint.y(), Rules_BackScream);
	drawFillBox(DrawFirstPoint.x(), DrawFirstPoint.y(), DrawCost.x(), DrawCost.y(), Color(ColorBox,ColorBox,ColorBox,BackGroundTransparency));
	if (BackGroundTransparency >= 0.5f)
		RulesAnimation();

	
	
}

void Rules::RulesAnimation()
{
	RulesFont.draw("���������߂�", Vec2f(-500.0f, 400.0f), Color::white);
	RulesFont.draw("�������̓J���^���I���イ���L�[�ł������������ق������ɂ�������I", Vec2f(-700.0f, 300.0f), Color::white);
	RulesFont.draw("���낢�����΂��炨����ƃX�^�[�g������Ȃ��������炫�����悤�I", Vec2f(-725.0f, 200.0f), Color::white);
	RulesFont.draw("�܂��A����Ȃ̂��ɂӂ�Ȃ��łˁB", Vec2f(-700.0f, 100.0f), Color::white);
	RulesFont.draw("���߂��ɂ��ザ�񂱂������ǂ������ăQ�[�����X�^�[�g�����悤�I", Vec2f(-700.0f, 0.0f), Color::white);
	drawFillBox(600, -200, 650, -250, Color::white);
	if (CanMoveFlag == true)
	{
		if (env.isPressKey(GLFW_KEY_LEFT))
		{
			LamaDrawPos.x() -= 3;
			LeftMove = true;
			RightMove = false;
			UpMove = false;
			DownMove = false;

			if (LeftMove == true)
			{
				AnimationCount++;
			}
		}

		else if (env.isPressKey(GLFW_KEY_RIGHT))
		{
			LamaDrawPos.x() += 3;
			LeftMove = false;
			RightMove = true;
			UpMove = false;
			DownMove = false;

			if (RightMove == true)
			{
				AnimationCount++;
			}
		}

		else if (env.isPressKey(GLFW_KEY_UP))
		{
			LamaDrawPos.y() += 3;
			LeftMove = false;
			RightMove = false;
			UpMove = true;
			DownMove = false;

			if (UpMove == true)
			{
				AnimationCount++;
			}
		}

		else if (env.isPressKey(GLFW_KEY_DOWN))
		{
			LamaDrawPos.y() -= 3;
			LeftMove = false;
			RightMove = false;
			UpMove = false;
			DownMove = true;

			if (DownMove == true)
			{
				AnimationCount++;
			}
		}

		if (AnimationCount >= 60 || env.isPullKey(GLFW_KEY_UP) || env.isPullKey(GLFW_KEY_DOWN) || env.isPullKey(GLFW_KEY_RIGHT) || env.isPullKey(GLFW_KEY_LEFT))
		{
			AnimationCount = 0;
		}
	}

	if (LeftMove == true)
	{
		if (AnimationCount >= 0 && AnimationCount < 15)
		{
			drawTextureBox(LamaDrawPos.x(), LamaDrawPos.y(), LamaSize.x(), LamaSize.y(), 0.0f, 128.0f, TextureDrawCos.x(), TextureDrawCos.y(), Rules_Lama);
		}
		if (AnimationCount >= 15 && AnimationCount < 30)
		{
			drawTextureBox(LamaDrawPos.x(), LamaDrawPos.y(), LamaSize.x(), LamaSize.y(), 64.0f, 128.0f, TextureDrawCos.x(), TextureDrawCos.y(), Rules_Lama);
		}
		if (AnimationCount >= 30 && AnimationCount < 45)
		{
			drawTextureBox(LamaDrawPos.x(), LamaDrawPos.y(), LamaSize.x(), LamaSize.y(), 128.0f, 128.0f, TextureDrawCos.x(), TextureDrawCos.y(), Rules_Lama);
		}
		if (AnimationCount >= 45 && AnimationCount <= 60)
		{
			drawTextureBox(LamaDrawPos.x(), LamaDrawPos.y(), LamaSize.x(), LamaSize.y(), 192.0f, 128.0f, TextureDrawCos.x(), TextureDrawCos.y(), Rules_Lama);
		}
	}

	else if (RightMove == true)
	{
		if (AnimationCount >= 0 && AnimationCount < 15)
		{
			drawTextureBox(LamaDrawPos.x(), LamaDrawPos.y(), LamaSize.x(), LamaSize.y(), 0.0f, 256.0f, TextureDrawCos.x(), TextureDrawCos.y(), Rules_Lama);
		}
		if (AnimationCount >= 15 && AnimationCount < 30)
		{
			drawTextureBox(LamaDrawPos.x(), LamaDrawPos.y(), LamaSize.x(), LamaSize.y(), 64.0f, 256.0f, TextureDrawCos.x(), TextureDrawCos.y(), Rules_Lama);
		}
		if (AnimationCount >= 30 && AnimationCount < 45)
		{
			drawTextureBox(LamaDrawPos.x(), LamaDrawPos.y(), LamaSize.x(), LamaSize.y(), 128.0f, 256.0f, TextureDrawCos.x(), TextureDrawCos.y(), Rules_Lama);
		}
		if (AnimationCount >= 45 && AnimationCount <= 60)
		{
			drawTextureBox(LamaDrawPos.x(), LamaDrawPos.y(), LamaSize.x(), LamaSize.y(), 192.0f, 256.0f, TextureDrawCos.x(), TextureDrawCos.y(), Rules_Lama);
		}
	}

	else if (UpMove == true)
	{
		if (AnimationCount >= 0 && AnimationCount < 15)
		{
			drawTextureBox(LamaDrawPos.x(), LamaDrawPos.y(), LamaSize.x(), LamaSize.y(), 0.0f, 384.0f, TextureDrawCos.x(), TextureDrawCos.y(), Rules_Lama);
		}
		if (AnimationCount >= 15 && AnimationCount < 30)
		{
			drawTextureBox(LamaDrawPos.x(), LamaDrawPos.y(), LamaSize.x(), LamaSize.y(), 64.0f, 384.0f, TextureDrawCos.x(), TextureDrawCos.y(), Rules_Lama);
		}
		if (AnimationCount >= 30 && AnimationCount < 45)
		{
			drawTextureBox(LamaDrawPos.x(), LamaDrawPos.y(), LamaSize.x(), LamaSize.y(), 128.0f, 384.0f, TextureDrawCos.x(), TextureDrawCos.y(), Rules_Lama);
		}
		if (AnimationCount >= 45 && AnimationCount <= 60)
		{
			drawTextureBox(LamaDrawPos.x(), LamaDrawPos.y(), LamaSize.x(), LamaSize.y(), 192.0f, 384.0f, TextureDrawCos.x(), TextureDrawCos.y(), Rules_Lama);
		}
	}

	else if (DownMove == true)
	{
		if (AnimationCount >= 0 && AnimationCount < 15)
		{
			drawTextureBox(LamaDrawPos.x(), LamaDrawPos.y(), LamaSize.x(), LamaSize.y(), 0, 0.0f, TextureDrawCos.x(), TextureDrawCos.y(), Rules_Lama);
		}
		if (AnimationCount >= 15 && AnimationCount < 30)
		{
			drawTextureBox(LamaDrawPos.x(), LamaDrawPos.y(), LamaSize.x(), LamaSize.y(), 64.0f, 0.0f, TextureDrawCos.x(), TextureDrawCos.y(), Rules_Lama);
		}
		if (AnimationCount >= 30 && AnimationCount < 45)
		{
			drawTextureBox(LamaDrawPos.x(), LamaDrawPos.y(), LamaSize.x(), LamaSize.y(), 128.0f, 0.0f, TextureDrawCos.x(), TextureDrawCos.y(), Rules_Lama);
		}
		if (AnimationCount >= 45 && AnimationCount <= 60)
		{
			drawTextureBox(LamaDrawPos.x(), LamaDrawPos.y(), LamaSize.x(), LamaSize.y(), 192.0f, 0.0f, TextureDrawCos.x(), TextureDrawCos.y(), Rules_Lama);
		}
	}

	else
	{
		drawTextureBox(LamaDrawPos.x(), LamaDrawPos.y(), LamaSize.x(), LamaSize.y(), 0.0f, 256.0f, TextureDrawCos.x(), TextureDrawCos.y(), Rules_Lama);
	}

}

void Rules::RulesReset()
{
	BackGroundTransparency = 0.0f;
	TextureFirstPoint = 0.0f;
	ColorBox = 0.0f;
	AnimationCount = 0.0f;
	CanMoveFlag = true;
	LamaDrawPos = Vec2f(-630.0f, -400.0f);
	
}