#include "Singleton.h"
#include "Result.h"

Result::Result()
{
	ResultFont.size(100);
}

void Result::Setup()
{
	AlfaFlag = true;
}

void Result::Update()
{
	if (AlfaFlag == true)
	{
		Alfa += 0.01f;
	}

	if (Alfa >= 1.0f)
	{
		AlfaFlag = false;
		Alfa2 += 0.01;
	}

	if (Alfa2 >= 1.0f)
	{
		Alfa2 = 1.0f;
		Alfa3 += 0.01;
	}

	if (Alfa3 >= 1.0f)
	{
		Alfa3 = 1.0f;
	}
}

void Result::SoundSet()
{
	ResultSound.play();
	ResultSound.gain(0.7);
	ResultSound.looping(true);
}

void Result::SoundStop()
{
	ResultSound.stop();
}

void Result::Draw()
{
	drawFillBox(-750.0f, -500.0f, 1500.0f, 1000.0f, Color::white);
	ResultFont.draw("������ł���Ă��肪�ƁI", Vec2f(-500.0f, 200.0f), Color(ColorR, ColorG, ColorB, Alfa));
	ResultFont.draw("���̂����Ђ�����̂��݂ɁI", Vec2f(-600.0f, 0.0f), Color(ColorR, ColorG, ColorB, Alfa2));
	ResultFont.draw("�Ђ���N���b�N�Ń^�C�g����", Vec2f(-500.0f, -200.0f), Color(ColorR, ColorG, ColorB, Alfa3));
}

void Result::Reset()
{
	Alfa  = 0.0f;
	Alfa2 = 0.0f;
	Alfa3 = 0.0f;
}