#pragma once
#include "lib/framework.hpp"
#include "Singleton.h"

class Rules
{
private:

	Texture Rules_BackScream;
	Texture Rules_Lama;
	Font RulesFont = Font("res/MyComSquare-Medium.otf");
	Media RulesSound = Media("res/lovesickness.wav");
	Media Sound = Media("res/yubi.wav");

public:
	Rules();

	void Draw();
	void Setup();
	void Update();
	void SoundSet();
	void RulesReset();
	void RulesAnimation();
	void SoundStop();

	Vec2f DrawFirstPoint         = Vec2f(-750.0f, -500.0f);
	Vec2f DrawEndPoint           = Vec2f(1500.0f, 1000.0f);
	Vec2f DrawCost               = Vec2f(1500.0f, 1000.0f);
	Vec2f TextureEndPoint        = Vec2f(4096.0f, 2048.0f);
	Vec2f LamaDrawPos;
	Vec2f LamaSize;
	Vec2f TextureDrawCos;

	float BackGroundTransparency = 0.0f;
	float TextureFirstPoint      = 0.0f;
	float ColorBox               = 0.0f;
	float AnimationCount;

	bool RightMove;
	bool LeftMove;
	bool UpMove;
	bool DownMove;
	bool CanMoveFlag = true;

};