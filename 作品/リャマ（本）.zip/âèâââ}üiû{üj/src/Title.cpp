#include "Title.h"

Title::Title()
{
	TitleBack = Texture("res/title.png");
	TitleRogo = Texture("res/TitleRogo.png");
}

void Title::Setup()
{
	TitleFont.size(100);
}

void Title::Update()
{
	TransparencyCount++;

	if (TransparencyCount > 30)
	{
		Transparency -= 0.1f;
	}
	if (env.isPushButton(Mouse::LEFT))
		CrickSound.play();

}

void Title::SoundSet()
{
	TitleBackSound.play();
	TitleBackSound.gain(0.7f);
	TitleBackSound.looping(true);
}

void Title::SoundStop()
{
	TitleBackSound.stop();
}

void Title::Draw()
{
	drawTextureBox(-750, -500, 1500, 1000, 0, 0, 4096, 2048, TitleBack);
	drawTextureBox(Startdraw_x, Startdraw_y, Enddraw_x, Enddraw_y, 0, 0, 1024, 256, TitleRogo);
	drawFillBox(-750.0f, -500.0f, 1500.0f, 1000.0f, Color(1.0f, 1.0f, 1.0f, Transparency));
	if (TransparencyCount <30)
	{
		TitleFont.draw("K presents", Vec2f(-300, 0), Color::black);
	}
	else
	{
		TitleFont.draw("���N���b�N�ł�����", Vec2f(-500, -200), Color::magenta);
	}
}

void Title::TitleReset()
{
	Transparency = 1.0f;
	TransparencyCount = 0.0f;
}